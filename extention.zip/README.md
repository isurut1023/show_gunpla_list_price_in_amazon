# show_gunpla_list_price_in_amazon

https://chrome.google.com/webstore/detail/get-bandai-gunpla-price/cgoafblnjdodihodfjihblkalcmljhgg?hl=ja&authuser=0
