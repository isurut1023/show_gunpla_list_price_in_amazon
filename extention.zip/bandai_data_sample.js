const bandai_data_json = {
  "brand": [],
  "scale": [],
  "series": [],
  "products": []
}
